let age = prompt("How old are you?", "100");
alert(`You are ${age} years old!`);;