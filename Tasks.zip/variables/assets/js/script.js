let admin, namee;

namee = "John";

admin = namee;

alert(admin);

let planet;
planet = "earth";

let currentVisitor;
currentVisitor = "userName";
