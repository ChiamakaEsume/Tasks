let name = "Ilya";

alert(`hello ${1}`);
// It would show show alert 'hello 1'

alert(`hello ${"name"}`);
// It would show alert 'hello name'

alert(`hello ${name}`);
// It would show alert 'hello Ilya'
